# RFID - RC522 with Tiva C TM4C123G and CCS (Code Composer Studio)

## This project uses a RFID - RC522 with TM4C123G. The library was modified to work with Code Composer Studio.


### v1.0